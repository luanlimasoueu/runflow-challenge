locals {
  ad_lookup_compartment_id = var.tenancy_ocid != "" ? var.tenancy_ocid : var.compartment_ocid
  selected_ad              = data.oci_identity_availability_domains.ads.availability_domains[0].name
  selected_image_id        = data.oci_core_images.ubuntu.images[0].id
  instance_name            = "runflow-oci-saas-demo"
  instance_shape           = "VM.Standard.E5.Flex"
  ocpus                    = 1
  memory_in_gbs            = 8
  boot_volume_size_in_gbs  = 80
  vcn_cidr                 = "10.42.0.0/16"
  subnet_cidr              = "10.42.1.0/24"
  app_port                 = 3001

  bootstrap_script = templatefile("${path.module}/bootstrap.sh.tftpl", {
    app_port            = local.app_port
    runflow_api_key_b64 = base64encode(var.runflow_api_key)
    grok_api_key_b64    = base64encode(var.grok_api_key)
  })
}

data "oci_identity_availability_domains" "ads" {
  compartment_id = local.ad_lookup_compartment_id
}

data "oci_core_images" "ubuntu" {
  compartment_id           = var.compartment_ocid
  operating_system         = "Canonical Ubuntu"
  operating_system_version = "22.04"
  shape                    = local.instance_shape
  sort_by                  = "TIMECREATED"
  sort_order               = "DESC"
}

resource "oci_core_vcn" "runflow" {
  compartment_id = var.compartment_ocid
  cidr_block     = local.vcn_cidr
  display_name   = "${local.instance_name}-vcn"
  dns_label      = "runflowvcn"
}

resource "oci_core_internet_gateway" "runflow" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.runflow.id
  display_name   = "${local.instance_name}-igw"
  enabled        = true
}

resource "oci_core_route_table" "public" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.runflow.id
  display_name   = "${local.instance_name}-public-rt"

  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.runflow.id
  }
}

resource "oci_core_security_list" "public" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.runflow.id
  display_name   = "${local.instance_name}-public-sl"

  egress_security_rules {
    protocol    = "all"
    destination = "0.0.0.0/0"
  }

  ingress_security_rules {
    protocol = "6"
    source   = "0.0.0.0/0"

    tcp_options {
      min = 80
      max = 80
    }
  }
}

resource "oci_core_subnet" "public" {
  compartment_id             = var.compartment_ocid
  vcn_id                     = oci_core_vcn.runflow.id
  cidr_block                 = local.subnet_cidr
  display_name               = "${local.instance_name}-public-subnet"
  dns_label                  = "public"
  route_table_id             = oci_core_route_table.public.id
  security_list_ids          = [oci_core_security_list.public.id]
  prohibit_public_ip_on_vnic = false
}

resource "oci_core_instance" "runflow" {
  availability_domain = local.selected_ad
  compartment_id      = var.compartment_ocid
  display_name        = local.instance_name
  shape               = local.instance_shape

  shape_config {
    ocpus         = local.ocpus
    memory_in_gbs = local.memory_in_gbs
  }

  create_vnic_details {
    subnet_id        = oci_core_subnet.public.id
    assign_public_ip = true
    display_name     = "${local.instance_name}-vnic"
    hostname_label   = "runflow"
  }

  source_details {
    source_type             = "image"
    source_id               = local.selected_image_id
    boot_volume_size_in_gbs = local.boot_volume_size_in_gbs
  }

  metadata = {
    user_data = base64encode(local.bootstrap_script)
  }
}
